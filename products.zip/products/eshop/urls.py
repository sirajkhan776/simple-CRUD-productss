from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name='home'),
    path('addproduct/',views.addproduct,name = 'addproduct'),
    path('showproduct/',views.showproduct,name = 'showproduct'),
    path('updateproduct/<int:pk>',views.updateproduct,name = 'updateproduct'),
    path('productdetail/<int:pk>',views.productdetail,name = 'productdetail'),
    path('deleteproduct/<int:pk>',views.deleteproduct,name = 'deleteproduct'),
    
]
