from django.contrib import admin
from .models import products

class ProductAdmin(admin.ModelAdmin):
    list_display =('id','name','price','is_published','created_at')
    list_display_links = ('id','name')
    list_filter = ('price','name')
    search_fields = ['name','price']
    ordering = ['price']
    # list_editable = ['price']
    


# Register your models here.
admin.site.register(products,ProductAdmin)