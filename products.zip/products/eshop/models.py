from django.db import models
from matplotlib import image
from sqlalchemy import false
from datetime import datetime
# Create your models here.
class products(models.Model):
     image = models.ImageField()
     name = models.CharField(max_length=200,null=False,blank=False)
     price = models.DecimalField(max_digits=7,decimal_places=2)
     description =models.TextField(max_length=250)
     is_published = models.BooleanField(default=True)
     created_at = models.DateTimeField(default=datetime.now)

     def __str__(self):
        return self.name
