from attr import attrs, field, fields
from django import forms
from matplotlib import widgets
from .models import products

class ProductForm(forms.ModelForm):
     class Meta:
        model = products
        fields = ['image','name','price','description','is_published']
        widgets={
            'image':forms.FileInput(attrs={'class':'form-control'}),
            'name':forms.TextInput(attrs={'class':'form-control'}),
            'price':forms.TextInput(attrs={'class':'form-control'}),
            'description':forms.TextInput(attrs={'class':'form-control'}),
            'is_published':forms.Select(attrs={'class':'form-control'}),
        }
      