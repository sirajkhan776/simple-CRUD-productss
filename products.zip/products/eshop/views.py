from django.shortcuts import render,redirect
from regex import F
from.models import products
from .forms import ProductForm

# Create your views here.

def index(request):
    return render(request,"index.html")



def showproduct(request):
    show = products.objects.all()
    context={
        'sho' :show
    }
    return render(request,"showProduct.html",context)

def updateproduct(request,pk):
    product = products.objects.get(id=pk)
    form = ProductForm(instance=product)
    if request.method=='POST':
        form = ProductForm(request.POST,request.FILES,instance=product)
        if form.is_valid():
            form.save()
            return redirect('home')

    context={
         'form':form
           }

    return render(request,'updateproduct.html',context)

def productdetail(request,pk):
    eachproduct = products.objects.get(id=pk)
    context ={
        'eachpd':eachproduct
    }
    return render(request,"productdetail.html",context)

def deleteproduct(request,pk):
    delproduct = products.objects.get(id=pk)
    delproduct.delete()
    return redirect('showproduct')

def addproduct(request):
    form = ProductForm()
    if request.method=='POST':
        print("post")
        form = ProductForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            print("save")

            return redirect('home')
    else:
        form= ProductForm()
        print("not post")
    context={
        'form':form
    }
    return render(request,'addProduct.html',context)